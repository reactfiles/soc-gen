// const redux = require('redux');
// const createStore = redux.legacy_createStore;
// // type of action
// const ADD_HERO = "ADD_HERO";

// // action you want to take 
// function addHero(){
//     return {
//         type : ADD_HERO,
//         info : "First Redux Action"
//     }
// }
// const initialState = {
//     heroes : 0
// }
// let reducer = (state = initialState, action) => {
//     switch( action.type ){
//         case ADD_HERO : return { 
//             ...state,
//             heroes : state.heroes + 1
//         }
//         default : return state
//     }
// }
// const store = createStore( reducer );
// console.log(store.getState());
// const unsubscribe = store.subscribe( () => {
//     console.log("state updated", store.getState() )
// });
// store.dispatch(addHero());
// store.dispatch(addHero());
// store.dispatch(addHero());
// unsubscribe();

const redux = require('redux');
const createStore = redux.legacy_createStore;

const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";
const ADD_MOVIE = "ADD_MOVIE";
const REMOVE_MOVIE = "REMOVE_MOVIE";

function addHero(){
    return {
        type : ADD_HERO
    }
}
function removeHero(){
    return {
        type : REMOVE_HERO
    }
}

function addMovie(){
    return {
        type : ADD_MOVIE
    }
}
function removeMovie(){
    return {
        type : REMOVE_MOVIE
    }
}

const initialState = {
    heroes : 0,
    movies : 0
}
// to add another data you need to add another reducer

let reducer = (state = initialState, action) => {
    switch( action.type ){
        case ADD_HERO : return { 
            ...state,
            heroes : state.heroes + 1
        }
        case REMOVE_HERO : return { 
            ...state,
            movies : state.heroes - 1
        }
        case ADD_MOVIE : return { 
            ...state,
            movies : state.movies + 1
        }
        case REMOVE_MOVIE : return { 
            ...state,
            movies : state.movies - 1
        }
        default : return state
    }
}

const store = createStore( reducer );
// the initial run
console.log("state initialized ",store.getState());

const unsubscribe = store.subscribe( () => {
    console.log("state updated", store.getState() )
});
store.dispatch(addHero());// hero 1
store.dispatch(addHero());// hero 2
store.dispatch(addHero());// hero 3
//------------------------
store.dispatch(addMovie());// movie 1
store.dispatch(addMovie());// movie 2
store.dispatch(addMovie());// movie 3
//------------------------
store.dispatch(removeMovie());// movie 2
store.dispatch(removeHero());// hero 2
//------------------------

unsubscribe();