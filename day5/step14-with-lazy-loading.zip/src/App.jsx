import HomeComp from "./components/home";
import {lazy, useState, Suspense} from "react";
import {BrowserRouter, NavLink, Route, Routes} from "react-router";
import "./components/linkstyle.css";

let AquamanComp = lazy(() => import("./components/aquaman"));
let BatmanComp = lazy(() => import("./components/batman"));
let DarkKnightComp = lazy(() => import("./components/darkknight"));
let DarkKnightRaisesComp = lazy(() => import("./components/darkknightraises"));
let FlashComp = lazy(() => import("./components/flash"));
let NotFoundComp = lazy(() => import("./components/notfound"));
let SupermanComp = lazy(() => import("./components/superman"));
let WonderWomenComp = lazy(() => import("./components/wonderwomen"));




function App() {
  let stylecheck = ({isActive}) => isActive ? "box nav-link" : "nav-link";
  let [state, setState] = useState(0);
  return (
    <div className="container">
      <h1>React with Routes</h1>
      <button onClick={() => setState(Math.round(Math.random() * 1000))}>Change version from {state}</button>
      <BrowserRouter>
       {/* <ul className="nav">
        <li className="nav-item"> <Link className="nav-link" to="/">Home</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/batman">Batman</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/batman/movie1">Batman Movie 1</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/batman/movie2">Batman Movie 2</Link></li>

        <li className="nav-item"> <Link className="nav-link" to="/superman">Superman</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/flash">Flash</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/aquaman">Aquaman</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/wonderwomen">Wonderwomen</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/cyborg">Cyborg</Link></li>
       </ul> */}

       <ul className="nav">
        <li className="nav-item"> <NavLink className={ stylecheck } to="/">Home</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/batman">Batman</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/batman/movie1">Batman Movie 1</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/batman/movie2">Batman Movie 2</NavLink></li>

        <li className="nav-item"> <NavLink className={ stylecheck } to="/superman">Superman</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to={'/flash'}>Flash no params</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to={'/flash/'+state}>Flash with params</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/aquaman">Aquaman</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/wonderwomen">Wonderwomen</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/cyborg">Cyborg</NavLink></li>
       </ul>
      <Routes>
        <Route path="/" element={<HomeComp/>}/> {/* default route */}
        <Route path="/batman" element={<Suspense fallback={<span>...loading batman</span>}> <BatmanComp/></Suspense>}>
          <Route path="/batman/movie1" element={<Suspense fallback={<span>...loading DarkKnightComp</span>}> <DarkKnightComp/> </Suspense>}/>
          <Route path="/batman/movie2" element={<Suspense fallback={<span>...loading DarkKnightRaisesComp</span>}> <DarkKnightRaisesComp/> </Suspense>}/>
        </Route>{/* named route */}
        <Route path="/superman" element={<Suspense fallback={<span>...loading SupermanComp</span>}> <SupermanComp/></Suspense>}/>
        <Route path="/flash" element={<Suspense fallback={<span>...loading FlashComp</span>}> <FlashComp/> </Suspense>}/>
        <Route path="/flash/:ver" element={<Suspense fallback={<span>...loading FlashComp</span>}> <FlashComp/> </Suspense>}/>
        <Route path="/aquaman" element={<Suspense fallback={<span>...loading AquamanComp</span>}> <AquamanComp/></Suspense>}/>
        <Route path="/wonderwomen" element={<Suspense fallback={<span>...loading WonderWomenComp</span>}> <WonderWomenComp/> </Suspense>}/>
        <Route path="*" element={<Suspense fallback={<span>...loading NotFoundComp</span>}> <NotFoundComp/> </Suspense>}/> {/* notfound route */}
      </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App
