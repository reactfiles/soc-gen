function FlashComp() {
  return (
    <>
      <h2>Flash Component</h2>
    </>
  )
}

export default FlashComp
