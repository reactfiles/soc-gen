import AquamanComp from "./components/aquaman"
import BatmanComp from "./components/batman"
import DarkKnightComp from "./components/darkknight"
import DarkKnightRaisesComp from "./components/darkknightraises"
import FlashComp from "./components/flash"
import HomeComp from "./components/home"
import NotFoundComp from "./components/notfound"
import SupermanComp from "./components/superman"
import WonderWomenComp from "./components/wonderwomen"
import {BrowserRouter, Link, NavLink, Route, Routes} from "react-router";

import "./components/linkstyle.css";

function App() {
  let stylecheck = ({isActive}) => isActive ? "box nav-link" : "nav-link";
  return (
    <div className="container">
      <h1>React with Routes</h1>
  
      <BrowserRouter>
       {/* <ul className="nav">
        <li className="nav-item"> <Link className="nav-link" to="/">Home</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/batman">Batman</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/batman/movie1">Batman Movie 1</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/batman/movie2">Batman Movie 2</Link></li>

        <li className="nav-item"> <Link className="nav-link" to="/superman">Superman</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/flash">Flash</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/aquaman">Aquaman</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/wonderwomen">Wonderwomen</Link></li>
        <li className="nav-item"> <Link className="nav-link" to="/cyborg">Cyborg</Link></li>
       </ul> */}

       <ul className="nav">
        <li className="nav-item"> <NavLink className={ stylecheck } to="/">Home</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/batman">Batman</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/batman/movie1">Batman Movie 1</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/batman/movie2">Batman Movie 2</NavLink></li>

        <li className="nav-item"> <NavLink className={ stylecheck } to="/superman">Superman</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/flash">Flash</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/aquaman">Aquaman</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/wonderwomen">Wonderwomen</NavLink></li>
        <li className="nav-item"> <NavLink className={ stylecheck } to="/cyborg">Cyborg</NavLink></li>
       </ul>
      <Routes>
        <Route path="/" element={<HomeComp/>}/> {/* default route */}
        <Route path="/batman" element={<BatmanComp/>}>
          <Route path="/batman/movie1" element={<DarkKnightComp/>}/>
          <Route path="/batman/movie2" element={<DarkKnightRaisesComp/>}/>
        </Route>{/* named route */}
        <Route path="/superman" element={<SupermanComp/>}/>
        <Route path="/flash" element={<FlashComp/>}/>
        <Route path="/aquaman" element={<AquamanComp/>}/>
        <Route path="/wonderwomen" element={<WonderWomenComp/>}/>
        <Route path="*" element={<NotFoundComp/>}/> {/* notfound route */}
      </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App
