function NotFoundComp() {
  return (
    <>
      <h2>NotFound Component</h2>
    </>
  )
}

export default NotFoundComp
