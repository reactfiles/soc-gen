import { Outlet } from "react-router"

function BatmanComp() {
  return (
    <>
      <h2>Batman Component</h2>
      <Outlet />
    </>
  )
}

export default BatmanComp
