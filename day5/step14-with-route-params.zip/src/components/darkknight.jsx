function DarkKnightComp() {
  return (
    <>
      <h2>DarkKnight Component</h2>
    </>
  )
}

export default DarkKnightComp
