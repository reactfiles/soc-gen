function HomeComp() {
  return (
    <>
      <h2>Home Component</h2>
    </>
  )
}

export default HomeComp
