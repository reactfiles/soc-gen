import { useParams } from "react-router"

function FlashComp() {
  let prarms = useParams()
  return (
    <>
      <h2>Flash Component</h2>
      <h3>{ prarms.ver ? "Parameters passed is : "+prarms.ver: "No parameters were passed"}</h3>
    </>
  )
}

export default FlashComp
