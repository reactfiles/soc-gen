function WonderWomenComp() {
  return (
    <>
      <h2>WonderWomen Component</h2>
    </>
  )
}

export default WonderWomenComp
