function SupermanComp() {
  return (
    <>
      <h2>Superman Component</h2>
    </>
  )
}

export default SupermanComp
