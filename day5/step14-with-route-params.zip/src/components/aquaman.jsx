function AquamanComp() {
  return (
    <>
      <h2>Aquaman Component</h2>
    </>
  )
}

export default AquamanComp
