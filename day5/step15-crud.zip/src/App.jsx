import { useEffect, useState } from "react";
import axios from "axios";

function App() {
  let [heroes, setHeroes] = useState([]);
  let [nhero, setNewHero] = useState([
                                        {
                                          uname : "",
                                          uage : "",
                                          ucity : ""
                                        }
                                      ]);
  let [ehero, setUpdateHero] = useState([
                                        {
                                          _id : "",
                                          uname : "",
                                          uage : "",
                                          ucity : ""
                                        }
                                      ]);
  let reload = () => {
    axios.get("http://localhost:2525/data").then(data => setHeroes(data.data));
  }
  useEffect(()=>{
    reload();
  },[]);

  let addHero = () => {
    axios.post("http://localhost:2525/data",nhero).then(res => {
      console.log(res)
      reload();
    })
  }
  let updateHandler = () => {
    axios.put("http://localhost:2525/update/"+ehero._id,ehero).then(res => {
      console.log(res)
      reload();
    })
  }
  let inputHandler = (evt) => {
    setNewHero({...nhero, 
        [evt.target.id] : evt.target.value,
    })
  }
  let e_inputHandler = (evt) => {
    setUpdateHero({...ehero, 
        [evt.target.id] : evt.target.value,
    })
  }
  let readToUpdateHandler = (evt) => {
    console.log("edit was clicked")
    axios.get("http://localhost:2525/update/"+evt.target.title).then(data => {
      console.log(data.data)
      setUpdateHero(data.data);
    })
  }
  let deleteHandler = (evt) => {
      axios.delete("http://localhost:2525/delete/"+evt.target.title).then(dbres =>{
         console.log(dbres.message)
         reload();
        })
  }
  return (
    <div className="container">
      <h1>React CRUD</h1>
      <hr />
      <div>
        <h2>Create Hero</h2>
        <div className="mb-3">
          <label htmlFor="uname" className="form-label">Hero Name</label>
          <input value={nhero.uname} onInput={inputHandler} className="form-control" id="uname" />
        </div>
        <div className="mb-3">
          <label htmlFor="uage" className="form-label">Hero Age</label>
          <input value={nhero.uage} onInput={inputHandler} className="form-control" id="uage" />
        </div>
        <div className="mb-3">
          <label htmlFor="ucity" className="form-label">Hero City</label>
          <input value={nhero.ucity} onInput={inputHandler} className="form-control" id="ucity" />
        </div>
        <div className="mb-3">
         <button onClick={addHero} className="btn btn-primary">Add New Hero</button>
        </div>
      </div>

      <hr />
      <div>
        <h2>Update Hero</h2>
        <div className="mb-3">
          <label htmlFor="uname" className="form-label">Update Hero Name</label>
          <input value={ehero.uname} onInput={e_inputHandler} className="form-control" id="uname" />
        </div>
        <div className="mb-3">
          <label htmlFor="uage" className="form-label">Update Hero Age</label>
          <input value={ehero.uage} onInput={e_inputHandler} className="form-control" id="uage" />
        </div>
        <div className="mb-3">
          <label htmlFor="ucity" className="form-label">Update Hero City</label>
          <input value={ehero.ucity} onInput={e_inputHandler} className="form-control" id="ucity" />
        </div>
        <div className="mb-3">
         <button onClick={updateHandler}  className="btn btn-primary">Update Hero</button>
        </div>
      </div>

      <table className="table table-striped">
        <thead className="table-dark">
          <tr>
            <th>Sl #</th>
            <th>Hero Name</th>
            <th>Hero Age</th>
            <th>Hero City</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          { heroes.map( (val, idx) => {
            return <tr key={ idx }>
                    <td>{idx+1}</td>
                    <td>{val.uname}</td>
                    <td>{val.uage}</td>
                    <td>{val.ucity}</td>
                    <td>
                      <button onClick={readToUpdateHandler} title={val._id} className="btn btn-warning">Edit Hero</button>
                    </td>
                    <td>
                      <button onClick={deleteHandler} title={val._id} className="btn btn-danger">Delete</button>
                    </td>
                </tr>
          })}
        </tbody>
      </table>
    </div>
  )
}

export default App
