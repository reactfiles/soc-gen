import HeroComp from "./herocomp"

function App() {
  return  <div>
            <h1>Redux toolkit</h1>
            <HeroComp/>
          </div>
}
export default App
