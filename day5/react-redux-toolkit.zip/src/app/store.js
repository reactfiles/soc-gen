import { configureStore } from "@reduxjs/toolkit";
import heroReducer from "../features/hero/heroslice"; 

const store = configureStore({
    reducer : {
        hero : heroReducer
    }
});

export default store;