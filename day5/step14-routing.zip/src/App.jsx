import AquamanComp from "./components/aquaman"
import BatmanComp from "./components/batman"
import FlashComp from "./components/flash"
import HomeComp from "./components/home"
import NotFoundComp from "./components/notfound"
import SupermanComp from "./components/superman"
import WonderWomenComp from "./components/wonderwomen"

function App() {
  return (
    <>
      <h1>React with Routes</h1>
      <HomeComp/>
      <BatmanComp/>
      <SupermanComp/>
      <FlashComp/>
      <AquamanComp/>
      <WonderWomenComp/>
      <NotFoundComp/>
    </>
  )
}

export default App
