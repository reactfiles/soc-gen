function BatmanComp() {
  return (
    <>
      <h2>Batman Component</h2>
    </>
  )
}

export default BatmanComp
