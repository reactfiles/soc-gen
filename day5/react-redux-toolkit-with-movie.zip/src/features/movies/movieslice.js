import { createSlice } from '@reduxjs/toolkit'

const initialState = { numberOfMovies: 0 }

const movieSlice = createSlice({
  name: 'movie',
  initialState,
  reducers: {
    increaseMovie(state) { state.numberOfMovies++ },
    decreaseMovie(state) { state.numberOfMovies-- },
    setMovie(state, action) { state.numberOfMovies = action.payload
    },
  },
})

export const { increaseMovie, decreaseMovie, setMovie } = movieSlice.actions;
export default movieSlice.reducer;