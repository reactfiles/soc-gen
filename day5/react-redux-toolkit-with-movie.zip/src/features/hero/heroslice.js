import { createSlice } from '@reduxjs/toolkit'

const initialState = { numberOfHeroes: 0 }

const heroSlice = createSlice({
  name: 'hero',
  initialState,
  reducers: {
    increaseHero(state) { state.numberOfHeroes++ },
    decreaseHero(state) { state.numberOfHeroes-- },
    setHero(state, action) { state.numberOfHeroes = action.payload
    },
  },
})

export const { increaseHero, decreaseHero, setHero } = heroSlice.actions;
export default heroSlice.reducer;