import { configureStore } from "@reduxjs/toolkit";
import heroReducer from "../features/hero/heroslice"; 
import movieReducer from "../features/movies/movieslice"; 

const store = configureStore({
    reducer : {
        hero : heroReducer,
        movie : movieReducer
    }
});

export default store;