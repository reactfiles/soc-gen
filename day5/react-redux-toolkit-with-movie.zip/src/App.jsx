import HeroComp from "./herocomp"
import MovieComp from "./moviecomp"

function App() {
  return  <div>
            <h1>Redux toolkit</h1>
            <HeroComp/>
            <hr />
            <MovieComp/>
          </div>
}
export default App
