import { useDispatch, useSelector } from "react-redux";
import { decreaseHero, increaseHero, setHero } from "./features/hero/heroslice";

let HeroComp = () =>{
    let numberOfHeroes = useSelector( (state) => state.hero.numberOfHeroes );
    let dispatch = useDispatch();
    return <div>
                <h2>Hero Component</h2>
                <h3>Avengers Count : {numberOfHeroes}</h3>
                <button onClick={()=> dispatch(increaseHero())}>Increase Hero count</button>
                <button onClick={()=> dispatch(decreaseHero())}>Decrease Hero count</button>
                <input type="number" onChange={(evt) => dispatch(setHero(Number(evt.target.value)))} />
           </div>
};

export default HeroComp