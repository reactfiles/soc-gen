import { useDispatch, useSelector } from "react-redux";
import { decreaseMovie, increaseMovie, setMovie } from "./features/movies/movieslice";

let MovieComp = () =>{
    let numberOfMovies = useSelector( (state) => state.movie.numberOfMovies );
    let dispatch = useDispatch();
    return <div>
                <h2>Movie Component</h2>
                <h3>Movie Count : {numberOfMovies}</h3>
                <button onClick={()=> dispatch(increaseMovie())}>Increase Movie count</button>
                <button onClick={()=> dispatch(decreaseMovie())}>Decrease Movie count</button>
                <input type="number" onChange={(evt) => dispatch(setMovie(Number(evt.target.value)))} />
           </div>
};

export default MovieComp