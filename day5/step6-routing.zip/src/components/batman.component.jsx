export let BatmanComponent = () => {
    return <div>
        <h1>
            Batman Component
        </h1>
    </div>
}