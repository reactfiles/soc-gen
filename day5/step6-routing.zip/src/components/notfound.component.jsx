export let NotFoundComponent = () => {
    return <div>
        <h1>
            NotFound Component : 404
        </h1>
    </div>
}
