export let AquamanComponent = () => {
    return <div>
        <h1>
            Aquaman Component
        </h1>
    </div>
}