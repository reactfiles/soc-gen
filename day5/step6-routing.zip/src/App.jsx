import React, { Suspense } from "react";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import { HomeComponent } from "./components/home.component";

let BatmanComp = React.lazy(() => import("./components/batman.component").then((m) => ({ default: m.BatmanComponent })));
let SupermanComp = React.lazy(() => import("./components/superman.component").then((m) => ({ default: m.SupermanComponent })));
let AquamanComp = React.lazy(() => import("./components/aquaman.component").then((m) => ({ default: m.AquamanComponent })));
let NotFoundComp = React.lazy(() => import("./components/notfound.component").then((m) => ({ default: m.NotFoundComponent })));

function App(){
  return <>
          <h1>Welcome to React Routing</h1>
          <BrowserRouter>
            {/* <ul>
              <li> <Link to="/">Home</Link> </li>
              <li> <Link to="/batman">Batman</Link> </li>
              <li> <Link to="/superman">Superman</Link> </li>
              <li> <Link to="/aquaman">Aquaman</Link> </li>
              <li> <Link to="/flash">Flash</Link> </li>
            </ul> */}
            <ul>
              <li> <Link to="/">Home</Link> </li>
              <li> <Link to="/batman">Batman</Link> </li>
              <li> <Link to="/superman">Superman</Link> </li>
              <li> <Link to="/aquaman">Aquaman</Link> </li>
              <li> <Link to="/flash">Flash</Link> </li>
            </ul>
            <Routes>
            {/*               
              <Route path="/" element={<HomeComponent/>}/>
              <Route path="/batman" element={<BatmanComponent/>}/>
              <Route path="/superman" element={<SupermanComponent/>}/>
              <Route path="/aquaman" element={<AquamanComponent/>}/>
              <Route path="*" element={<NotFoundComponent/>}/> 
              */}
              <Route path="/" element={<HomeComponent/>}/>
              <Route path="/batman" element={<Suspense fallback={<span>...loading Batman</span>}> <BatmanComp/> </Suspense> }/>
              <Route path="/superman" element={<Suspense fallback={<span>...loading Superman</span>}> <SupermanComp/> </Suspense> }/>
              <Route path="/aquaman" element={<Suspense fallback={<span>...loading Aquaman</span>}> <AquamanComp/> </Suspense> }/>
              <Route path="*" element={<Suspense fallback={<span>...loading 404</span>}> <NotFoundComp/> </Suspense> }/> 
            </Routes>
          </BrowserRouter>
        </>
}
export default App;


/* 

vijay.shivu@gmail.com


*/