import Avengers from "./features/avengers/Avengers";

export default function App() {
  return <Avengers />;
}
