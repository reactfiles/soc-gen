import { configureStore } from "@reduxjs/toolkit";
import avengersReducer from "../features/avengers/avengersSlice";

export const store = configureStore({
  reducer: { avengers: avengersReducer },
});
