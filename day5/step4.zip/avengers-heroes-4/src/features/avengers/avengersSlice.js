import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const fetchHeroes = createAsyncThunk("avengers/fetchHeroes", async () => {
  const res = await fetch("/api/heroes");
  if (!res.ok) throw new Error("Failed to fetch heroes");
  return res.json();
});

export const addHeroApi = createAsyncThunk("avengers/addHeroApi", async (name, { rejectWithValue }) => {
  const res = await fetch("/api/heroes", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });

  if (res.status === 409) return rejectWithValue("Hero already exists");
  if (!res.ok) return rejectWithValue("Failed to add hero");

  return res.json();
});

export const removeHeroApi = createAsyncThunk("avengers/removeHeroApi", async (id) => {
  const res = await fetch(`/api/heroes/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to remove hero");
  return id;
});

export const clearAllApi = createAsyncThunk("avengers/clearAllApi", async () => {
  const res = await fetch("/api/heroes", { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to clear");
  return true;
});

const avengersSlice = createSlice({
  name: "avengers",
  initialState: {
    heroes: [],
    status: "idle", // idle | loading | succeeded | failed
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      // fetch
      .addCase(fetchHeroes.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchHeroes.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.heroes = action.payload;
      })
      .addCase(fetchHeroes.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message ?? "Fetch failed";
      })

      // add
      .addCase(addHeroApi.fulfilled, (state, action) => {
        state.heroes.push(action.payload);
        state.error = null;
      })
      .addCase(addHeroApi.rejected, (state, action) => {
        state.error = action.payload ?? action.error.message ?? "Add failed";
      })

      // delete
      .addCase(removeHeroApi.fulfilled, (state, action) => {
        state.heroes = state.heroes.filter((h) => h.id !== action.payload);
      })

      // delete all
      .addCase(clearAllApi.fulfilled, (state) => {
        state.heroes = [];
      });
  },
});

export default avengersSlice.reducer;
