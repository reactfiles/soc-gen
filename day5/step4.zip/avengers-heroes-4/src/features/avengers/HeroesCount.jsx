import { useDispatch, useSelector } from "react-redux";
import { clearAllApi } from "./avengersSlice";

export default function HeroesCount() {
  const count = useSelector((s) => s.avengers.heroes.length);
  const status = useSelector((s) => s.avengers.status);
  const dispatch = useDispatch();

  return (
    <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 8 }}>
      <button onClick={() => dispatch(clearAllApi())} disabled={count === 0}>
        Clear all
      </button>

      <div style={{ marginLeft: "auto" }}>
        {status === "loading" ? "Loading..." : <>Total heroes: <b>{count}</b></>}
      </div>
    </div>
  );
}
