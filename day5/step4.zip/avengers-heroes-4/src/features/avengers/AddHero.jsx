import { useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addHeroApi } from "./avengersSlice";

export default function AddHero() {
  const [name, setName] = useState("");
  const dispatch = useDispatch();
  const error = useSelector((s) => s.avengers.error);

  const canAdd = useMemo(() => name.trim().length >= 2, [name]);

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!canAdd) return;

    const result = await dispatch(addHeroApi(name));
    if (addHeroApi.fulfilled.match(result)) setName("");
  };

  return (
    <div>
      <form onSubmit={onSubmit} style={{ display: "flex", gap: 8 }}>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter hero name"
          style={{ flex: 1, padding: 10 }}
        />
        <button type="submit" disabled={!canAdd}>Add</button>
      </form>

      {error && <p style={{ marginTop: 8, color: "crimson" }}>{error}</p>}
    </div>
  );
}
