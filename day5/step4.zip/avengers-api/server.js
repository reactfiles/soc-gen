import express from "express";
import cors from "cors";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";

const app = express();
app.use(cors());
app.use(express.json());

const DATA_PATH = path.resolve("data.json");

async function readData() {
  const raw = await readFile(DATA_PATH, "utf-8");
  return JSON.parse(raw);
}

async function writeData(data) {
  // Pretty-print makes the JSON human readable
  await writeFile(DATA_PATH, JSON.stringify(data, null, 2), "utf-8");
}

// Health
app.get("/health", (_req, res) => res.json({ ok: true }));

// Get all heroes
app.get("/api/heroes", async (_req, res) => {
  const data = await readData();
  res.json(data.heroes ?? []);
});

// Add hero
app.post("/api/heroes", async (req, res) => {
  const name = String(req.body?.name ?? "").trim();
  if (name.length < 2) return res.status(400).json({ error: "Name too short" });

  const data = await readData();
  const heroes = data.heroes ?? [];

  // Optional: prevent duplicates (case-insensitive)
  const exists = heroes.some((h) => h.name.toLowerCase() === name.toLowerCase());
  if (exists) return res.status(409).json({ error: "Hero already exists" });

  const hero = { id: crypto.randomUUID(), name };
  heroes.push(hero);

  await writeData({ heroes });
  res.status(201).json(hero);
});

// Remove hero by id
app.delete("/api/heroes/:id", async (req, res) => {
  const id = req.params.id;

  const data = await readData();
  const heroes = data.heroes ?? [];
  const next = heroes.filter((h) => h.id !== id);

  await writeData({ heroes: next });
  res.json({ ok: true });
});

// Clear all
app.delete("/api/heroes", async (_req, res) => {
  await writeData({ heroes: [] });
  res.json({ ok: true });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
