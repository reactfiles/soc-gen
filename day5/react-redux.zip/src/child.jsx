import { useDispatch, useSelector } from "react-redux";
import { addHero, removeHero, setHero } from "./redux/index";
let ChildComp = () =>{
    let dispatch = useDispatch();
    let numberOfHeroes = useSelector( (state) => state.numberOfHeroes  )
    return <div>
                <h1>React - Redux Ex</h1>
                <h2>Avengers Count : {numberOfHeroes}</h2>
                <button onClick={() => dispatch( addHero() )}>Increase Hero Count</button>
                <button onClick={() => dispatch( removeHero() )}>Decrease Hero Count</button>
                <input type="range" onChange={(evt) => dispatch( setHero(Number(evt.target.value)) )} />
            </div>
}

export default ChildComp;