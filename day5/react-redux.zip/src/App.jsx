import ChildComp from "./child"
import ParentComp from "./parent"

function App() {
  return  <div>
            <h1>React Redux</h1>
            <ChildComp/>
            <hr/>
            <ParentComp/>
          </div>
}
export default App