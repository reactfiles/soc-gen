import { useDispatch } from "react-redux";
import { removeHero } from "./redux/index";
let ReduceComp = () =>{
    let dispatch = useDispatch();
    return <div>
                <button onClick={() => dispatch( removeHero() )}>Decrease Hero Count</button>
           </div>
}

export default ReduceComp;