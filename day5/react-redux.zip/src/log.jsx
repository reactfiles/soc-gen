import { useSelector } from "react-redux";
let LogComp = () =>{
    let numberOfHeroes = useSelector( (state) => state.numberOfHeroes  )
    return <div>
                <h2>Log Avengers Count : {numberOfHeroes}</h2>
             </div>
}

export default LogComp;