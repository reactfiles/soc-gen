import LogComp from "./log"
import ReduceComp from "./reducecount"

let ParentComp = () => {
    return <div>
            <LogComp/>
            <hr />
            <ReduceComp/>
    </div>
}

export default ParentComp;