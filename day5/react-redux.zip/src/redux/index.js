import { addHero, removeHero, setHero } from "./actions/hero.actions";

export {
    addHero,
    removeHero,
    setHero
}