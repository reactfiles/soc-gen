import { ADD_HERO, REMOVE_HERO, SET_HERO } from "../types/hero.types"

const initialState = {
    numberOfHeroes : 0
}
export const heroReducer = (state = initialState, action) => {
    switch(action.type){
        case ADD_HERO : return {...state, numberOfHeroes : state.numberOfHeroes + 1 }
        case REMOVE_HERO : return {...state, numberOfHeroes : state.numberOfHeroes - 1 }
        case SET_HERO : return {...state, numberOfHeroes : action.payload }
        default : return state
    }
}