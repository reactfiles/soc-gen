import Avengers from "./components/Avengers";

export default function App() {
  return <Avengers />;
}
