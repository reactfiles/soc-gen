import { useDispatch, useSelector } from "react-redux";
import { removeHeroApi } from "../features/avengers/avengersSlice";

export default function HeroesList() {
  const heroes = useSelector((s) => s.avengers.heroes);
  const dispatch = useDispatch();

  if (heroes.length === 0) {
    return <p style={{ marginTop: 16, opacity: 0.7 }}>No heroes yet.</p>;
  }

  return (
    <ul style={{ marginTop: 18, paddingLeft: 18 }}>
      {heroes.map((h) => (
        <li key={h.id} style={{ display: "flex", gap: 10, marginBottom: 10 }}>
          <span style={{ flex: 1 }}>{h.name}</span>
          <button onClick={() => dispatch(removeHeroApi(h.id))}>Remove</button>
        </li>
      ))}
    </ul>
  );
}
