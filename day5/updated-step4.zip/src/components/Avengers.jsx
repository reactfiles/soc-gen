import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { fetchHeroes } from "../features/avengers/avengersSlice";
import AddHero from "./AddHero";
import HeroesCount from "./HeroesCount";
import HeroesList from "./HeroesList";

export default function Avengers() {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchHeroes());
  }, [dispatch]);

  return (
    <div style={{ maxWidth: 520, margin: "40px auto", fontFamily: "system-ui" }}>
      <h1>Avengers Heroes</h1>
      <AddHero />
      <HeroesCount />
      <HeroesList />
    </div>
  );
}
