import { useSelector } from "react-redux";

export default function HeroesCount() {
  const count = useSelector((s) => s.avengers.heroes.length);
  const status = useSelector((s) => s.avengers.status);

  return (
    <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 8 }}>

      <div style={{ marginLeft: "auto" }}>
        {status === "loading" ? "Loading..." : <>Total heroes: <b>{count}</b></>}
      </div>
    </div>
  );
}
