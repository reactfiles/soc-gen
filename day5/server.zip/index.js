const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const app = express();

app.use(express.json());
app.use(cors());

const config = require("./config.json");

// schema
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
// model
let Hero = mongoose.model("Hero", new Schema({
    id : ObjectId,
    uname : String,
    uage : String,
    ucity : String
}));
// config to connect to mongo db
mongoose.connect(config.dbstring)
.then((conres)=>{
    console.log("DB Connected")
}).catch(error => console.log("Error ", error))

// read
app.get("/data", function(req, res){
    Hero.find().then( dbres => res.json(dbres))
});
// create
app.post("/data", function(req, res){
    let hero = new Hero(req.body);
    hero.save().then(dbres => {
        res.json({
            message : "hero added to db"
        })
    })
});
// read before update
app.get("/update/:id", (req, res) => {
    console.log(req.params.id)
      Hero.findById(req.params.id)
      .then(dbres => res.json(dbres))
      .catch(error => console.log("Error", error))
});
// update
app.put("/update/:id", (req, res) => {
    Hero.findById(req.params.id).then(dbres => {
        dbres.uname = req.body.uname;
        dbres.uage = req.body.uage;
        dbres.ucity = req.body.ucity;

        dbres.save().then(updateRes => res.json({
            message : "Hero was updated"
        }))
    })
});
// delete
app.delete("/delete/:id", (req, res) => {
     Hero.findByIdAndDelete(req.params.id).then(dbres => {
        res.json({
            message : dbres+" was removed"
        })
     }).catch(error =>  console.log("Error", error ));
});

app.listen(config.port,config.host,(error) => {
    if(error){
        console.log("Error ",error)
    }else{
        console.log("server is live on localhost:2525")
    }
})

// node .
// npm i express mongoose cors 