function App() {
  let count = 10;
  let heroes = [ "Ironman", "Thor", "Hulk" ]
  return  <>
            <h1>{ 5 + 6 + count }</h1>
            <ul>{heroes.map( val => <li className="">{val}</li> )}</ul>
          </>
}
export default App