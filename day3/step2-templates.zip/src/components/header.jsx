let Header = () => {
    return (
        <header>
            <h2>Soc Gen Bangalore</h2>
        </header>
    )
};

export default Header