let Footer = () => {
    return (
        <footer>
            <p>Copy Rights &copy; reserved by soc gen Bangalore</p>
        </footer>
    )
};

export default Footer