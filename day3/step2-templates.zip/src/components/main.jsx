import Article from "./article";

let MainComp = () => {
    return (
        <main>
            <h2>Soc Gen Bangalore</h2>
            <Article/>
            <Article/>
        </main>
    )
};

export default MainComp