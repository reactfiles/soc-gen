let Article = () => {
    return (
        <article>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam assumenda autem nisi molestias voluptas. Obcaecati vel porro facilis labore rem amet distinctio tempora quae, quam nobis nulla molestias consequatur esse.
        </article>
    )
};

export default Article;