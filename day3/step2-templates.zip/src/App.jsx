import { Fragment } from "react";
import Footer from "./components/footer";
import Header from "./components/header";
import MainComp from "./components/main";

let App = () => {
  return (
    <Fragment>
      <Header/>
      <MainComp/>
      <Footer/>
    </Fragment>
  )
}

export default App;