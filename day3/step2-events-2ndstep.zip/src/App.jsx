import { useState, createRef } from "react"

function App() {
  // state 
  let [ power, setPower ] = useState(0);
  // console.log(useState(5), "will return an array");
  let callAlert = function(){
    alert("hello there")
  }
  let ip = createRef();
/*   
  let power = 0;
  let increasePower = function(){
    power++;
    console.log(power);
  } 
  */
 let increasePower = function(){
   setPower(power+1);
 } 
 let decreasePower = function(){
   setPower(power-1);
 } 
 let changePower = function(evt){
   setPower(Number(evt.target.value));
 } 
 let getPowerFromNumber = function(){
   setPower(Number(ip.current.value));
 } 
  return  <div style={ { border : "1px solid grey", width : "600px", margin : "auto", padding : "20px" } }>
            <h1>Events in React</h1>
            <button onClick={callAlert}>Alert</button>
            <h2>Power : {power}</h2>
            <button onClick={increasePower}>Increase Power</button>
            &nbsp;
            &nbsp;
            <button onClick={decreasePower}>Decrease Power</button>
            <br />
            <br />
            <input onChange={changePower} type="number" value={power} />
            <br />
            <br />
            <input onChange={changePower} type="range" value={power} />
            <br />
            <br />
            <input ref={ ip } type="number" />
            <button onClick={ getPowerFromNumber }>Change Power</button>
          </div>
}
export default App