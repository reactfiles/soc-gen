let ChildComp = ({show,title,version,color}) => {
    return (
        <>
        { 
        show ? <div style={ {backgroundColor : color, width : "500px", border : "1px solid grey", padding : "10px", margin : "10px"} }>
                    <div>Child Component</div>
                    <div>Title : {title}</div>
                    <div>Version : {version * 10}</div>
                </div> : ""
        }
        </>
    )
}
export default ChildComp