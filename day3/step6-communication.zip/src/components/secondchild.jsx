let SecondChild = ({children}) => {
    return (
        <>
        <h3> Second Child Component </h3>
       <div style={ {border : "2px dashed black", padding : "10px"} }>
         { children }
       </div>
        </>
    )
};

export default SecondChild ;