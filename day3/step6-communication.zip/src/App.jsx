import { useState } from "react";
import ChildComp from "./components/childcomp";
import SecondChild from "./components/secondchild";
let App = () => {
  let [vals, setTitles] = useState([
    { title : "first child component", version : 1, color : "red", show:true },
    { title : "second child component", version : 2, color : "orange", show:true },
    { title : "third child component", version : 3, color : "blue", show:false },
    { title : "fourth child component", version : 4, color : "green", show:true },
   
  ])
  return (
    <>
      <h1>Communication</h1>
      { vals.map((val, idx) => <ChildComp show={val.show} color={ val.color } key={idx} version={val.version} title={val.title}/>) }
      <hr />
      <SecondChild>
        <button>Click Me</button>
        <ul>
          <li>List Item 1</li>
          <li>List Item 2</li>
          <li>List Item 3</li>
          <li>List Item 4</li>
          <li>List Item 5</li>
        </ul>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Illo harum eos pariatur, iste et esse vel commodi praesentium ipsam ea distinctio omnis beatae perferendis, exercitationem consequatur. Odio dolor harum temporibus?
        </p>
      </SecondChild>
    </>
  )
}
export default App
/* 
props
children
loops
communicate from parent to child
communicate from child to parent
---------------------------------
communication of siblings
*/