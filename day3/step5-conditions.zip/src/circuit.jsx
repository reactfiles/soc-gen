import { useState } from "react";

let Circuit = () => {
    let [show, setShow] = useState(true);
    return (
        <>
        <h1>Circuit Operator</h1>
        <input type="checkbox" onChange={() => setShow(!show)} /> {show ? "Show" : "Hide" } Terms & Conditions
        { show || <fieldset>
                    <legend>Terms & Conditions</legend>
                    <hr />
                    <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Animi dolorem harum, laudantium vero nesciunt consequuntur sed possimus eaque debitis et minima illum impedit sequi a cupiditate sapiente voluptatibus, ipsam adipisci!
                    Sequi omnis saepe hic quam, facilis, excepturi quas suscipit commodi voluptatem ullam provident reprehenderit harum labore quis reiciendis delectus fugit blanditiis ea at mollitia modi illum error quos vel? Excepturi.
                    Veniam ullam, repellat debitis qui omnis exercitationem dignissimos alias impedit recusandae labore architecto? Ea totam consectetur illo quia suscipit, modi velit laudantium nemo et atque excepturi porro dolore? Hic, dolorum.
                    Porro ex dolor omnis debitis cum illo a quo perspiciatis! Est blanditiis quas debitis animi voluptate quos perferendis ducimus, facilis totam nulla, eos obcaecati, reiciendis fugiat laudantium fugit repudiandae provident.
                    Deleniti odit, obcaecati nisi est iure soluta incidunt vitae tenetur? Distinctio voluptate iste natus. Voluptatibus, tempore assumenda labore perspiciatis odio cupiditate eos molestiae, fugit soluta, maxime numquam at ipsam voluptatem!
                    Deserunt quos expedita eaque repudiandae, molestiae cumque omnis dolores quia incidunt deleniti, maxime, soluta quidem sequi at impedit provident sit. Officia quae voluptates animi, sed quos eligendi placeat? Porro, assumenda.
                    Dolore vero odio voluptate, et asperiores alias omnis? Optio autem id, alias ea culpa voluptate impedit molestiae odit saepe, blanditiis illo accusantium, molestias quisquam cumque minus eligendi harum quam. At.
                    Vitae ipsa sunt impedit quaerat deserunt quis id hic, labore mollitia aspernatur obcaecati modi ab ex adipisci, perspiciatis accusantium, esse omnis ducimus sint. Eveniet quam cumque consectetur, blanditiis excepturi voluptas?
                    Dolorum autem, doloribus necessitatibus aut magnam quis, dolore iste unde mollitia laboriosam excepturi est inventore ratione aliquam at natus deserunt. Odit ea aspernatur velit eligendi reiciendis iste dolore culpa molestiae!
                    Maxime porro, labore esse, dolores nisi expedita sint sit, laboriosam dolore ab minus id consequuntur aspernatur? Aliquam impedit nihil quae necessitatibus, corporis ab sunt facere, quis veniam quos ad qui?
                    </p>
                </fieldset> }
        </>
    )
}

export default Circuit;