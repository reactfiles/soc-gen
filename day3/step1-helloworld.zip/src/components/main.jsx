export default function Main(){
    return <main className="box">
            <h1>Main Area { 5 + 5 } { new Date().getDate() }</h1>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Corrupti nulla amet tenetur dolores repellat omnis voluptatem expedita illum, earum maiores eos fugit harum molestias molestiae doloremque quisquam nobis consequatur consectetur? Dignissimos quos ullam in laborum fugit distinctio voluptates ab perspiciatis ea sequi quibusdam vero, sapiente quam quidem autem ducimus temporibus?
            </p>
            <hr/>
            <label htmlFor="terms">Agree</label>
            <input id="terms" type="checkbox" />
          </main>
}