export default function Footer(){
    return <footer>
            <h4>&copy; Copyrights reserved by Society Generale : India </h4>
           </footer>
}