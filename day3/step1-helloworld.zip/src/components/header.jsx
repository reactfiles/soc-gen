function Header(){
    return <header>
            <h1>Header Area</h1>
          </header>
}
export default Header;