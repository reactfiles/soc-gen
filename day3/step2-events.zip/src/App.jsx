import { useState } from "react"

function App() {
  let [ power, setPower ] = useState(0);
  // console.log(useState(5), "will return an array");
  let callAlert = function(){
    alert("hello there")
  }
/*   
  let power = 0;
  let increasePower = function(){
    power++;
    console.log(power);
  } 
  */
 let increasePower = function(){
   setPower(power+1);
 } 
 let decreasePower = function(){
   setPower(power-1);
 } 
 let changePower = function(evt){
   setPower(Number(evt.target.value));
 } 
  return  <div style={ { border : "1px solid grey", width : "600px", margin : "auto", padding : "20px" } }>
            <h1>Events in React</h1>
            <button onClick={callAlert}>Alert</button>
            <h2>Power : {power}</h2>
            <button onClick={increasePower}>Increase Power</button>
            <button onClick={decreasePower}>Decrease Power</button>
            <input onChange={changePower} type="number" value={power} />
          </div>
}
export default App