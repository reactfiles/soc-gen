import React, { useState } from "react";
function App() {
  /* 
  let count = 0;
  let increaseCount = () => {
    console.log("increaseCount was called");
    count += 1;
    console.log(count);
  } 
  */
  // console.log(useState());
  let [count, increaseCount] = useState(0);
  let [tempcount, tempIncreaseCount] = useState(0);

  let increaseHandler = () =>{
    increaseCount(count+1);
  };
  let decreaseHandler = () =>{
    increaseCount(count-1);
  };
  let inputHandler = (event) =>{
    increaseCount(Number(event.target.value));
    // console.log("inputHandler was called")
  };
  let setCountHandler = () =>{
    increaseCount(Number(tempcount));
  };
  let setCountHandler2 = () =>{
    increaseCount(Number(ipref.current.value));
  };

  let ipref = React.createRef();

  return (
    <>
      <h1>Count : { count }</h1>
      <button onClick={increaseHandler}>Increase Count</button>
      <br />
      <br />
      <button onClick={decreaseHandler}>Decrease Count</button>
      <br />
      <br />
      <input value={count} onChange={(evt) => inputHandler(evt) } type="range" />
      <hr />
      <input value={tempcount} 
      onInput={(evt) => tempIncreaseCount(evt.target.value)} 
      onChange={(evt) => tempIncreaseCount(evt.target.value)} type="number" />
      <button onClick={setCountHandler}>Set Value From Number using State Input</button>
      <hr />
      <input ref={ipref} type="number" />
      <button onClick={setCountHandler2}>Set Value From Number Input</button>
    </>
  )
}
export default App
