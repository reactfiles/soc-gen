let App = () => <h1>Welcome to your life !!!</h1>;

export default App;