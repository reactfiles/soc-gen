import { Component } from "react";
class SecondComp extends Component{
    render(){
        return <h2>Second Component</h2>
    }
};
export default SecondComp;