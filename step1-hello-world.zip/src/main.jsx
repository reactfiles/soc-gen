import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import SecondComp from './second.jsx';

createRoot(document.getElementById('root'))
.render( <div>
            <App />
            <SecondComp/>
         </div> )