function App() {
  return  <div>
            <h1>Step 1</h1>
          </div>
}

export default App

/* 
Styles
Form Validation
State Management
  Context
  Redux
*/

/* 
Routing
CRUD
*/