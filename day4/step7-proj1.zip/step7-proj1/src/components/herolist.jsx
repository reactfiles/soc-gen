let HeroList = ({list, title}) => {
    return (
        <div style={ { width : "300px", fontFamily : "sans-serif", padding : "15px", backgroundColor : "silver", border : "1px solid grey"} }>
            <h1 style={ {margin : "0px"} }>{title}</h1>
            <hr />
            <ol>
                { list.map((val, idx) => <li key={idx}>{ val }</li>)}
            </ol>
        </div>
    )
};

export default HeroList;