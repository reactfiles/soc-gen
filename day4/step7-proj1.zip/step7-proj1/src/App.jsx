import { useState } from "react";
// import Christina from "./components/christina";
// import "./mystyle.css";
import HeroList from "./components/herolist";
import { useRef } from "react";

let App = () => {
let [avengers, setHeroes] = useState([]);
let [justiceleague, setJLHeroes] = useState([]);
let ipref = useRef();
let jlref = useRef();
let clickHandler = function(){
  if(ipref.current.value && avengers.length < 10){
    setHeroes([...avengers, ipref.current.value]);
    ipref.current.value = "";
    ipref.current.focus();
  }
}
let jlHandler = function(){
  if(jlref.current.value && justiceleague.length < 10){
    setJLHeroes([...justiceleague, jlref.current.value]);
    jlref.current.value = "";
    jlref.current.focus();
  }
}
 return <div>
          <h2>Heroes List Application</h2>
          <input ref={ipref} type="text" />
          <button onClick={clickHandler} >Add Hero</button>
          <br />
          <br />
          <input ref={jlref} type="text" />
          <button onClick={jlHandler} >Add Hero</button>
          <HeroList title="Avengers" list={avengers}/>
          <HeroList title="Justice League" list={justiceleague}/>
          {/* <main>
            <Christina/>
          </main> */}
        </div>;
}

export default App;