import ChildComp from "./components/child"
import socgen from "./client.module.css";
import "./app.css";

function App() {
  return (
    <div className="box">
      <h1>Styles</h1>
      <ChildComp/>
      <div className="box">
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Totam accusamus voluptatem minima autem excepturi explicabo provident vel non illum laudantium quia officia similique eos eligendi error deserunt a, adipisci nesciunt?
      </div>
      <div className={socgen.box}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus veniam possimus magni quam consequatur, aspernatur fugit laboriosam ea recusandae harum saepe praesentium voluptatem obcaecati non molestias expedita! Doloremque, inventore nam.
      </div>
      <div className="box">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde quaerat obcaecati sapiente vitae vero impedit amet odio quas, corporis ea nemo vel libero repellendus voluptates ex? Delectus odio debitis iste.
      </div>
    </div>
  )
}

export default App
