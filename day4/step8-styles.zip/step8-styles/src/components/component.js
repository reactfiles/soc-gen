let h2style = { 
    backgroundColor : "darkslateblue", 
    color: "aliceblue"
};

export default h2style;