import h2style from "./component.js";

let ChildComp = () => { 
    return (
        <div>
            <h2 style={ h2style }>Child Component</h2>
            <h2 style={ {...h2style, backgroundColor : "darkgoldenrod"} }>Child Component</h2>
            <h2 style={ h2style }>Child Component</h2>
            <h2 style={ {...h2style, backgroundColor : "crimson"} }>Child Component</h2>
            <h2 style={ h2style }>Child Component</h2>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quis expedita iure error quibusdam quidem sunt quos cum delectus veniam repellat sequi deleniti animi quaerat, esse facilis architecto praesentium iusto et.
            </p>
            <button className="btn btn-primary">Click Me</button>
            <button className="btn btn-warning">Click Me</button>
            <button className="btn btn-danger">Click Me</button>
            <button className="btn btn-info">Click Me</button>
        </div>
    )
    
}

export default ChildComp

{/*
 inline style 
 external style
 component style
 application style
 additional style libraries
 style modules
*/}