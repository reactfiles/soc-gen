import React from "react";

let FamilyContext = React.createContext();

{/* 
    FamilyContext.Provider
    FamilyContext.Consumer
    FamilyContext.displayName
*/}

export default FamilyContext;