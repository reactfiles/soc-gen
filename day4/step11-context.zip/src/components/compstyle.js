export let compStyle = {
    margin: "0px", 
    backgroundColor : "burlywood" , 
    padding : "10px", 
    border : "2px solid grey",
    width : "400px",
    fontFamily : "sans-serif",
    display : "table"
};
