import ChildComp from "./childcomp";
import { compStyle } from "./compstyle";

let ParentComp = () => {
    return (
        <div style={ {...compStyle, backgroundColor : "rgb(150, 119, 77)"} }>
            <h2>Parent Component</h2>
            <ChildComp/>
        </div>
    )
};

export default ParentComp;