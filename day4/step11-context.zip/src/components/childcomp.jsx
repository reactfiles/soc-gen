import { useContext } from "react";
import FamilyContext from "../contexts/familycontext";
import { compStyle } from "./compstyle";

let ChildComp = () => {
    let famContext = useContext(FamilyContext);
    return (
        <div style={ {...compStyle, backgroundColor : "#826132"} }>
            <h2>Child Component</h2>
            <FamilyContext.Consumer>{(val)=><p>Message <span  style={ {color : "whitesmoke"} }>{val}</span></p>}</FamilyContext.Consumer>
            <h2>Access Message from hook : {famContext}</h2>
        </div>
    )
};

export default ChildComp;