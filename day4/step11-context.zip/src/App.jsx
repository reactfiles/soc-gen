import GrandParentComp from "./components/grandparentcomp"

function App() {
  return (
    <>
      <h1>Using Context</h1>
      <GrandParentComp/>
    </>
  )
}

export default App
