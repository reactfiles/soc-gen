import { useState } from "react"
import ChildComp from "./component/child"
import { useRef } from "react";
import CousinComp from "./component/cousin";

function App() {
  let [show, setShow] = useState(true);
  let [state, setState] = useState({
                                      childTitle : "default title",
                                      childVersion : 555
                                    });
  let titleRef = useRef();
  // let rangeRef = useRef();
  return (
    <div>
      <h1>Lifecycle of a component <br/> {"Title is "+state.childTitle+" Version : "+state.childVersion} </h1>
      {/* <input ref={rangeRef} type="range" onChange={() => setState({...state, childVersion : rangeRef.currnet.value })} /> */}
      <input type="range" onChange={(evt) => setState({...state, childVersion : evt.target.value })} />
      <input ref={titleRef} type="text" />
      <button onClick={() => setState({...state, childTitle : titleRef.current.value })}>Change Title</button>
      <hr />
      <button onClick={() => setShow(!show)}>Show / Hide</button>
      <hr />
      { show || <ChildComp title={state.childTitle} version={state.childVersion}/> }
      <CousinComp/>
    </div>
  )
}

export default App
