import { useEffect } from "react";

let CousinComp = () => {
    useEffect(function(){
        console.log("Cousin Component was re-rendered", Math.random());
    });
    return <div>
                <h2>Cousin Component</h2>
            </div>
};

export default CousinComp;