import { useEffect } from "react";

let ChildComp = (props) => {

    useEffect(function(){
        console.log("Child Component was mounted", Math.random());
    },[]);

    useEffect(function(){
        console.log("Prop Version Changed", Math.random());
    },[props.version]);

    useEffect(function(){
        console.log("Some Prop was Changed", Math.random());
    });

    useEffect(function(){
        return function(){
            console.log("Child Component was unmounted");
        }
    },[]);
    
    return <div>
                <h2>Child Component</h2>
                <h3>Title : {props.title}</h3>
                <h3>Version : {props.version}</h3>
            </div>
};

export default ChildComp;