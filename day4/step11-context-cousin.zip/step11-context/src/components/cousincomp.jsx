import { useContext } from "react";
import FamilyContext from "../contexts/familycontext";
import { compStyle } from "./compstyle";

let CousinComp = () => {
    let famContext = useContext(FamilyContext);
    return (
        <div style={ {...compStyle, backgroundColor : "#473419"} }>
            <h2>Cousin Component</h2>
            <h2>Access Message from hook : {famContext}</h2>
        </div>
    )
};

export default CousinComp;