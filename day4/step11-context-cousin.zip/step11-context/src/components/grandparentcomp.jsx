import ParentComp from "./parentcomp";
import { compStyle } from "./compstyle";
import { useRef, useState } from "react";
import FamilyContext from "../contexts/familycontext";
import CousinComp from "./cousincomp";


let GrandParentComp = () => {
    let [message, setMessage] = useState("");
    let ipref = useRef();
    return (
        <div style={ compStyle }>
            <h2 >GrandParent Component</h2>
            <input ref={ipref}  />
            <button onClick={ () => setMessage( ipref.current.value )}>Send Message</button>
            <br />
            <br />
            <FamilyContext.Provider value={message}>
                <ParentComp />
                <CousinComp/>
            </FamilyContext.Provider>
        </div>
    )
};

export default GrandParentComp;