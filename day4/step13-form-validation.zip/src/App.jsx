function App() {
  return (
    <div className="container">
      <h1>Form Data and Validation</h1>
      <form action="" method="get">
          <div className="mb-3">
            <label htmlFor="uname" className="form-label">User Name</label>
            <input name="uname" className="form-control" id="uname" />
          </div>
          <div className="mb-3">
            <label htmlFor="uage" className="form-label">User Age</label>
            <input name="uage" type="number" className="form-control" id="uage" />
          </div>
          <div className="mb-3">
            <label htmlFor="ucity" className="form-label">User City</label>
            <input name="ucity" type="text" className="form-control" id="ucity" />
          </div>
          <div className="mb-3">
            <button type="submit" class="btn btn-primary mb-3">Submit Data</button>
          </div>
      </form>
    </div>
  )
}

export default App
