let UserComp = ({ name, email, address, phone, website, company }) => {
    return (
        <div style={ { float : "left", border : "5 dashed grey", width : "450px", background : "silver", fontFamily : "sans-serif", padding : "10px", margin : "15px"} }>
            <h1 style={ {margin : "0px", backgroundColor : "black", color : "aliceblue"} }>{name}</h1>
            <address>
                <a href={"mailto:"+email}>{email}</a>
                {"street : "+address.street}
                <br />
                {"suite : "+address.suite}
                <br />
                {"city : "+address.city}
                <br />
                {"zipcode : "+address.zipcode}
                <br />
                {"phone : "+phone}
                <br />
                {"website :"+website}
            </address>
            <h3 style={ {margin : "0px"} }>Company {company.name}</h3>
        </div>
    )
};
export default UserComp;
