import { useState } from "react";
import UserComp from "./components/user";
import { useEffect } from "react";
import axios from "axios";

function App() {
  let [userdata, setUserData] = useState([]);
  useEffect(()=>{
    axios.get("https://jsonplaceholder.typicode.com/users")
    .then(data => {
      setUserData(data.data);
      console.log(JSON.stringify(data.data));
    })
  },[]);
  return (
    <>
      <h1>Using Data</h1>
      { userdata.map(val => <UserComp {...val} key={val.id}/>) }
    </>
  )
}

export default App
