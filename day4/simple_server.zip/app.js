const express = require("express");
const cors = require("cors");
const fs = require("node:fs");
const { json } = require("node:stream/consumers");
const app = express();

app.use(express.json());
app.use(cors());

let serverdata = [
  {
    "id": 1,
    "name": "Leanne Graham",
    "email": "Sincere@april.biz",
    "phone": "1-770-736-8031 x56442",
    "website": "hildegard.org",
    "company":"Romaguera-Crona"
  }
];

/* fs.readFile("./data.json","utf-8",function(error,data){
    if(error){
        console.log("Error", error)
    }else{
        console.log(data);
        serverdata = JSON.parse(data);
    }
});
 */
app.get("/",function(req, res){
    res.send(serverdata);
})
app.post("/",function(req, res){
    serverdata.push(JSON.parse(JSON.stringify({
        id : serverdata.length+1,
        name : req.body.uname,
        email : req.body.uemail,
        phone : req.body.uphone,
        website : req.body.uwebsite,
        company : req.body.ucompany,
    })));
    res.send({
        message : "data recieved on express server ",
        recievedData : req.body,
        updatedData : serverdata
    })
})

app.listen(3030,"localhost",function(error){
    if(error) console.log("Error ", error)
    else console.log("Express is now live on localhost:3030")
})