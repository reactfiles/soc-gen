let ChildComp = () => {
    return <div>
                <h2>Child Component</h2>
            </div>
};

export default ChildComp;