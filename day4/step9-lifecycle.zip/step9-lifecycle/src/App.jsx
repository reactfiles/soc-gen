import ChildComp from "./component/child"

function App() {
  return (
    <div>
      <h1>Lifecycle of a component</h1>
      <hr />
      <ChildComp/>
    </div>
  )
}

export default App
