import "./user.css";

function UserComp(props){
    return <div className="box">
                <h2>Name : { props.data?.name }</h2>
                <div className="email">eMail : { props.data?.email }</div>
                <div>Phone : { props.data?.phone }</div>
                <div>Website : { props.data?.website }</div>
                <div>Company : { props.data?.company }</div>
           </div>
}
export default UserComp