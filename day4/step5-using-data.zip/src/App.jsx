import { useEffect, useState } from "react"
import UserComp from "./components/user";
import axios from "axios";
import "./app.css";

function App() {
  let [data, setData] = useState([]);
  let [userformstate, setUserFormState] = useState({
    uname : "",
    uemail : "",
    uphone : "",
    uwebsite : "",
    ucompany : "",
  });

  useEffect(()=>{
    axios.get("http://localhost:3030/")
    .then(res => {
      setData(res.data);
    })
  },[]);
  let clickHandler = () => {
    axios.post("http://localhost:3030/",userformstate)
    .then(res => {
      setData(res.data.updatedData);
      // console.log(res.data.updatedData);
    })
  }
  /* 
  let formNameHandler = (evt) => {
    setUserFormState({
        ...userformstate,
        uname : evt.target.value
    })
  }
  let formeMailHandler = (evt) => {
    setUserFormState({
        ...userformstate,
        uemail : evt.target.value
    })
  }
  let formPhoneHandler = (evt) => {
    setUserFormState({
        ...userformstate,
        uphone : evt.target.value
    })
  }
  let formWebsiteHandler = (evt) => {
    setUserFormState({
        ...userformstate,
        uwebsite : evt.target.value
    })
  }
  let formCompanyHandler = (evt) => {
    setUserFormState({
        ...userformstate,
        ucompany : evt.target.value
    })
  } 
  */
  let formInputHandler = (evt) => {
    setUserFormState({
        ...userformstate,
        [evt.target.id] : evt.target.value
    })
  }
  return  <div>
            <h1>API Request</h1>
           <div className="userform">
            <h2 style={ {textAlign : "center"} }>Create New User</h2>
             <div>
                <label htmlFor="uname">Name</label>
                <input value={userformstate.uname} onChange={formInputHandler} id="uname" type="text" />
              </div>
             <div>
                <label htmlFor="uemail">eMail</label>
                <input value={userformstate.uemail}  onChange={formInputHandler}  id="uemail" type="text" />
              </div>
             <div>
                <label htmlFor="uphone">Phone</label>
                <input value={userformstate.uphone} onChange={formInputHandler} id="uphone" type="text" />
              </div>
             <div>
                <label htmlFor="uwebsite">Website</label>
                <input value={userformstate.uwebsite} onChange={formInputHandler} id="uwebsite" type="text" />
              </div>
             <div>
                <label htmlFor="ucompany">Company</label>
                <input value={userformstate.ucompany} onChange={formInputHandler} id="ucompany" type="text" />
              </div> 
             {/* 
              */}
             <div>
                <button onClick={clickHandler}>Add New User</button>
              </div>
           </div>
           <p>{JSON.stringify(userformstate)}</p>
            <hr />
            { data.map(val => <UserComp key={val.id} data={val}/>) }
          </div>
}

export default App